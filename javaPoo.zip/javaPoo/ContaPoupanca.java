public class ContaPoupanca extends Conta{

    public ContaPoupanca(double novoSaldo, int novoNumeroConta, int novaAgencia){
        super(novoSaldo, novoNumeroConta, novaAgencia);
    }

    

}