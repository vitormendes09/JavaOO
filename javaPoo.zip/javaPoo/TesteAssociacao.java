public class TesteAssociacao {
    public static void main(String[] args) {

        // Conta contaDoVitor = new Conta();

        // Me referenciando ao objeto conta
        // contaDoVitor.saldo = 3000;
        // contaDoVitor.numeroConta = "333333";
        // contaDoVitor.agenciaConta = "013";
        // contaDoVitor.cliente = new Cliente();


        // Me referenciando ao objeto cliente que está dentro do objeto conta 
        // contaDoVitor.cliente.nome = "Vitor Silva Mendes";
        // contaDoVitor.cliente.cpf= "111.111.111-11";
        // contaDoVitor.cliente.idade = 20;
        // contaDoVitor.cliente.profissao = "Estudante";

        // System.out.println(contaDoVitor.saldo);
        
    }
    
}
