public class TestePolimorfismo {
    public static void main(String[] args) {
        
       ContaCorrente vitor = new ContaCorrente(200,456,423);

       vitor.Depositar(100);

       ContaPoupanca talita = new ContaPoupanca(200, 55, 23);
       talita.Depositar(500);

       vitor.Transferir(100, talita);

       System.out.println(vitor.pegarSaldo());

       System.out.println(talita.pegarSaldo());
       
    }
}
