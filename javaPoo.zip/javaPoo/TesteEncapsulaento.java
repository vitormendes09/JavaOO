public class TesteEncapsulaento {
    public static void main(String[] args) {
        

        // Conta ContaDoVitor = new Conta();


        // Errado, o certo é invocar um método para retornar um valor
        // ContaDoVitor.saldo = 10;

        // Princípios do encapsulamento, privatizar os atributos para que as classes não possam se referir aos atributos diretamente 
        // Se referir a um atributo diretamente pode causar ...
        // criar um método pegarX para asseçar o atributo 

        // Get --- Pegar -- Normalmente não gera retorno ( função do tipo void) e serve para acessasar ou pegar o atributo da classe sem mexer nele diretamente 

        // Set --- Alterar -- Normalmente possiu retorno (tipo do retorno é o mesmo que o tipo do atributo) e server para inserir valores dentro dos atributos sem que acessemos ele diretamente 

        




    }
    
}
