public class Cliente {
    private String nome;
    private String cpf;
    private String profissao;
    private int idade;

    public String pegarNome(){
        return this.nome;
    }

    public void alterarNome( String novoNome){
        this.nome = novoNome;
    }

    public String pegarCpf(){
        return this.cpf;
    }

    public void alterarCpf(String novoCpf){
        this.cpf = novoCpf;

    }

    public String pegarProfissao(){
        return this.profissao;
    }

    public void alterarProfissao(String novaprofissao){
        this.profissao = novaprofissao;
    }

    public int pegarIdade(){
        return this.idade;
    }

    public void alterarIdade(int novaIdade){
        this.idade = novaIdade;
    }
}
