public class main{
    public static void main(String [] args){

        // Criação dos objetos
        Conta primeiroTitutar= new Conta(100, 12233445, 013);
        Conta segundoTitular = new Conta(20,56677889,013);


        Cliente primeiroCliente = new Cliente();
        Cliente segundoCliente = new Cliente();

        // Associação

        primeiroTitutar.alterarCliente(primeiroCliente);
        segundoTitular.alterarCliente(segundoCliente);

        
        // Colocando valor nos atributos primeiro titular
        // ------------------- Antes do contrutor ------------------------
        // primeiroTitutar.alterarSaldo(100);
        // primeiroTitutar.alterarNumeroConta(12233445);
        // primeiroTitutar.alterarAgenciaConta(013);
        primeiroCliente.alterarCpf("111.111.111-11");
        primeiroCliente.alterarNome("Vitor Silva Mendes");
        primeiroCliente.alterarIdade(20);
        primeiroCliente.alterarProfissao("Estudante");

        System.out.println("================================================================");
        System.out.println("Dados do primeiro titular da conta:");
        System.out.println(" ");
        System.out.println("Saldo em conta do primeiro titular: " + primeiroTitutar.pegarSaldo() + "$");
        System.out.println("Numero da conta do primeiro titular: " + primeiroTitutar.pegarNumeroConta());
        System.out.println("Agencia da conta do primeiro Titular: " + primeiroTitutar.pegarAgenciaConta());
        System.out.println("Cpf do primeiro titular: " +primeiroCliente.pegarCpf());
        System.out.println("Nome do primeiro titular: "+ primeiroCliente.pegarNome());
        System.out.println("Idade do primeiro titular: " + primeiroCliente.pegarIdade());
        System.out.println("A profissão do primeiro Titular é: " + primeiroCliente.pegarProfissao());
        System.out.println("================================================================");

        // Colocando valor nos atributos segundo titular
        // ------------------- Antes do contrutor ------------------------
        // segundoTitular.alterarSaldo(20);;
        // segundoTitular.alterarNumeroConta(56677889);
        // segundoTitular.alterarAgenciaConta(013);
        segundoCliente.alterarCpf("222.222.222-22"); 
        segundoCliente.alterarNome("Talita Da Silva Merlim");  
        segundoCliente.alterarIdade(19);
        segundoCliente.alterarProfissao("Marketing Digital");


        System.out.println("Dados do segundo titular da conta:");
        System.out.println(" ");
        System.out.println("Saldo em conta do segundo titular: " + segundoTitular.pegarSaldo() + "$");
        System.out.println("Numero da conta do segundo titular: " + segundoTitular.pegarNumeroConta());
        System.out.println("Agencia da conta do segundo Titular: " +segundoTitular.pegarAgenciaConta());
        System.out.println("Cpf do segundo titular: " +segundoCliente.pegarCpf());
        System.out.println("Nome do segundo titular: "+ segundoCliente.pegarNome());
        System.out.println("Idade do segundo titular " + segundoCliente.pegarIdade());
        System.out.println("A profissão do segundo Titular é: " + segundoCliente.pegarProfissao());
        System.out.println("=================================================================");

        // Depositando valores nos saldos
        primeiroTitutar.Depositar(50);
        segundoTitular.Depositar(30);

        System.out.println("Depositando...");
        System.out.println(" ");
        System.out.println("O valor atual da conta do primeiro titular após deposito é: " + primeiroTitutar.pegarSaldo()+ "$");
        System.out.println("O valor atual da conta do segundo titular após deposito é: " + segundoTitular.pegarSaldo() + "$");
        System.out.println("=================================================================");

        // Sacando valores do saldo
        boolean retirada1 = primeiroTitutar.Sacar(20);
        boolean retirada2= segundoTitular.Sacar(3);

        System.out.println("sacando...");
        System.out.println(" ");
        System.out.println("A retirada do primeiro titular foi válidada ? " +retirada1);
        System.out.println("A retirada do segundo titular foi validada ?" + retirada2);
        System.out.println("O valor atual da conta após tentativa de saque do primeiro titular é: " +primeiroTitutar.pegarSaldo()+ "$");
        System.out.println("O valor atual da conta após tentativa de saque do segundo titular é: " + segundoTitular.pegarSaldo() + "$");
        System.out.println("=================================================================");

        // Transferencia valores saldo

        boolean transferencia = primeiroTitutar.Transferir(30, segundoTitular);

        System.out.println("Transferindo...");
        System.out.println(" ");

        System.out.println("A transferencia foi realizada com sucesso ? " + transferencia);
        System.out.println("Novo saldo atual do primeiro titular é: " + primeiroTitutar.pegarSaldo());
        System.out.println("Novo saldo atual do segundo titular é: " + segundoTitular.pegarSaldo());


    }
}
