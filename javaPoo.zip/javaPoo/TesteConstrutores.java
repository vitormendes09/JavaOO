public class TesteConstrutores {
    public static void main(String[] args) {
        
        //  Conta ContaDoVitor = new Conta(-4,33,33);

        // Con  taDoVitor.alterarAgenciaConta(-49);
        // ContaDoVitor.alterarNumeroConta(-66);

        // System.out.println(ContaDoVitor.pegarAgenciaConta());
        // System.out.println(ContaDoVitor.pegarNumeroConta());


        // Pode haver situações em que o cliente faça algo inesperado, como por numeros negativos nas agencias e nos numeros das contas
        // Caso isso aconteça, podemos acesssar diretamente os sets ( Alterar ) colocar ifs para que não seja possível ocorrer essas inconveniencias


        // Mas acontece que se você fizer apenas isso, quando seu codigo rodar os valores dos atributos estaram zerados(Enfaze que: zerados e não nulos como variáveis normais )
        // Para evitar isso, podemos criar os ditos construtores, que impoe valores pré determinados por quem está programando o sistema para que, se o usuário colocar um valor invalido ( Neste caso menor ou igual a 0 ) ele tenha um valor diferente e coerente com a situação 


        // Isso são chamados construtores, caso você crie um objeto, antes mesmo que você ponha valores em seu atributo, os construtores já iram por valores pré determinados
        // O contrutor é identificado por um método publico com o mesmo nome da classe
        // Inclusive podemos fazer o construtor receber parametros para que o usuário já os passe ( Não dando oportunidades de atribuir valores nulos e alterando os valores ao mesmo tempo )

        // System.out.println(ContaDoVitor.pegarSaldo());


    }   
}
