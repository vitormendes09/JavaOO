public class ContaCorrente extends Conta{

    public ContaCorrente(double novoSaldo, int novoNumeroConta, int novaAgencia ){
        super(novoSaldo, novoNumeroConta, novaAgencia);
    }
    

}
