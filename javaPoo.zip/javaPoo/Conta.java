public class Conta{
    private double saldo;
    private int numeroConta;
    private int agenciaConta;
    private Cliente cliente;

    // Contrutor 

    public Conta(double novoSaldo, int novoNumeroConta, int novaAgencia){ // Cliente novoCliente ??

        // this.saldo = novoSaldo;
        // this.numeroConta = novoNumeroConta;
        // this.agenciaConta = novaAgencia;
        // this.cliente = novoCliente;

        alterarSaldo(novoSaldo);
        alterarNumeroConta(novoNumeroConta);
        alterarAgenciaConta(novaAgencia);
        // alterarCliente(novoCliente);
    }

    //Encapsulamento -- get ou pegar 

    public double pegarSaldo(){
        return this.saldo;
    }

    public int pegarNumeroConta(){
        return this.numeroConta;
    }

    public int pegarAgenciaConta(){

        return this.agenciaConta;
    }

    public Cliente pegarCliente(){
        return this.cliente;
    }

    // Encapsulamento -- set ou alterar

    public void alterarSaldo( double novoSaldo){

        if(novoSaldo <= 0){   
            
            novoSaldo =  5;

            return;
            
        }
        this.saldo = novoSaldo;
    }

    public void alterarNumeroConta (int novoNumeroConta){

        if(novoNumeroConta <= 0){


            return;

        }

        this.numeroConta = novoNumeroConta;

    }

    public void alterarAgenciaConta(int novaAgencia){

        if(novaAgencia <= 0){

            return;

        }

        this.agenciaConta = novaAgencia;
    }

    public void alterarCliente(Cliente novoCliente){
        this.cliente = novoCliente;
    }

    // Métodos, ações  

    public void Depositar(double valor){

        this.saldo += valor;

    }

    public boolean Sacar(double valor){
        if(this.saldo >= valor){

            this.saldo -= valor;
            return true;

        } else {

            return false;
            
        }
    }

    public boolean Transferir(double valor, Conta destino ){

        if(this.saldo >= valor){
            this.saldo -= valor;
            destino.Depositar(valor);
            return true;
        } else {
            return false;
        } 
          
    }



    
}